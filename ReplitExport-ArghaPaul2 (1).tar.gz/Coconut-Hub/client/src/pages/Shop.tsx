import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

const CATEGORIES = [
  { id: "all", label: "All Products" },
  { id: "coconut_milk", label: "Milk & Cream" },
  { id: "coconut_oil", label: "Virgin Oil" },
  { id: "coconut_meat", label: "Meat & Chips" },
  { id: "coconut_husk", label: "Husk & Fiber" },
];

export default function Shop() {
  const [activeCategory, setActiveCategory] = useState("all");
  const { data: products, isLoading } = useProducts(
    activeCategory === "all" ? undefined : activeCategory
  );

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <div className="bg-secondary/10 py-12 border-b">
        <div className="container mx-auto px-4">
          <h1 className="font-display text-4xl font-bold text-primary mb-4">Shop Collection</h1>
          <p className="text-muted-foreground max-w-2xl">
            Explore our full range of ethically sourced coconut products. 
            From your kitchen pantry to industrial applications.
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12 flex-1">
        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 mb-12">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                "px-6 py-2 rounded-full text-sm font-medium transition-all duration-200",
                activeCategory === cat.id
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                  : "bg-secondary/10 text-muted-foreground hover:bg-secondary/20 hover:text-foreground"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="flex flex-col space-y-3">
                <Skeleton className="h-[300px] w-full rounded-2xl" />
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : products?.length === 0 ? (
          <div className="text-center py-24 text-muted-foreground">
            <p className="text-xl">No products found in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products?.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
