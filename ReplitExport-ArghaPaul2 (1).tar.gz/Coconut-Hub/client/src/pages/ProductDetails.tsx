import { useRoute } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { Minus, Plus, ShoppingBag, Truck, ShieldCheck, Leaf } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function ProductDetails() {
  const [, params] = useRoute("/products/:id");
  const id = parseInt(params?.id || "0");
  const { data: product, isLoading } = useProduct(id);
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="container mx-auto px-4 py-12 flex-1">
          <div className="grid md:grid-cols-2 gap-12">
            <Skeleton className="aspect-square rounded-3xl" />
            <div className="space-y-4">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-6 w-1/4" />
              <Skeleton className="h-32 w-full" />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Product not found</h2>
            <Button className="mt-4" onClick={() => window.history.back()}>Go Back</Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem(product);
    }
  };

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <main className="container mx-auto px-4 py-12 lg:py-20 flex-1">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Image Gallery */}
          <div className="relative rounded-3xl overflow-hidden bg-secondary/10 border border-border">
             {/* Dynamic image from API */}
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-full object-cover aspect-square hover:scale-105 transition-transform duration-700"
            />
          </div>

          {/* Product Info */}
          <div className="flex flex-col space-y-8">
            <div>
              {product.isB2BOnly && (
                <Badge className="mb-4 bg-primary text-primary-foreground">B2B Only</Badge>
              )}
              <h1 className="font-display text-4xl lg:text-5xl font-bold text-primary mb-4">
                {product.name}
              </h1>
              <p className="text-2xl font-medium text-foreground">
                {formatPrice(product.price)}
              </p>
            </div>

            <div className="prose prose-stone text-muted-foreground">
              <p>{product.description}</p>
              <ul>
                <li>Organic & Non-GMO</li>
                <li>Sustainably Harvested</li>
                <li>100% Traceable Supply Chain</li>
              </ul>
            </div>

            {/* Actions */}
            <div className="pt-6 border-t border-border">
              {!product.isB2BOnly ? (
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center border border-border rounded-xl h-12 w-32 bg-background">
                      <button 
                        className="flex-1 h-full flex items-center justify-center hover:bg-secondary/20 transition-colors"
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="font-medium">{quantity}</span>
                      <button 
                        className="flex-1 h-full flex items-center justify-center hover:bg-secondary/20 transition-colors"
                        onClick={() => setQuantity(quantity + 1)}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  <Button size="lg" className="w-full h-14 rounded-xl text-lg gap-2" onClick={handleAddToCart}>
                    <ShoppingBag className="w-5 h-5" />
                    Add to Cart - {formatPrice(product.price * quantity)}
                  </Button>
                </div>
              ) : (
                <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                  <h3 className="font-bold text-blue-900 mb-2">Bulk Order Required</h3>
                  <p className="text-blue-800 mb-4">This product is available for wholesale purchase only.</p>
                  <Button className="w-full" asChild>
                    <a href="/b2b">Request Quote</a>
                  </Button>
                </div>
              )}
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-3 gap-4 pt-6">
              <div className="flex flex-col items-center text-center gap-2">
                <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center text-primary">
                  <Truck className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium">Fast Shipping</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center text-primary">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium">Quality Guarantee</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center text-primary">
                  <Leaf className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium">100% Organic</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
