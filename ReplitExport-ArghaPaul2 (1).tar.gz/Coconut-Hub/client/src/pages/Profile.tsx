import { useAuth } from "@/hooks/use-auth";
import { useOrders } from "@/hooks/use-orders";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Redirect } from "wouter";
import { Loader2, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Profile() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: orders, isLoading: ordersLoading } = useOrders();

  if (authLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/" />;
  }

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("en-US", {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <main className="container mx-auto px-4 py-12 flex-1">
        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <h1 className="font-display text-4xl font-bold text-primary mb-2">My Account</h1>
            <p className="text-muted-foreground">Welcome back, {user.firstName}.</p>
          </div>

          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Package className="w-6 h-6 text-primary" /> Order History
          </h2>

          {ordersLoading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <div key={i} className="h-32 bg-secondary/10 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : orders?.length === 0 ? (
            <div className="text-center py-12 bg-secondary/5 rounded-3xl border border-dashed">
              <p className="text-muted-foreground">No orders yet.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {orders?.map((order) => (
                <div key={order.id} className="bg-card border rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <div>
                      <p className="font-bold text-lg">Order #{order.id}</p>
                      <p className="text-sm text-muted-foreground">{formatDate(order.createdAt as string)}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge variant={order.status === 'delivered' ? 'default' : 'secondary'} className="capitalize">
                        {order.status}
                      </Badge>
                      <p className="font-bold text-lg text-primary">{formatPrice(order.total)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
