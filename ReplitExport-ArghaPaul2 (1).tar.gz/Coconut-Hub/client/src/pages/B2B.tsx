import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertInquirySchema, type InsertInquiry } from "@shared/schema";
import { useCreateInquiry } from "@/hooks/use-inquiries";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Check, Package, Leaf, Globe2 } from "lucide-react";

export default function B2B() {
  const mutation = useCreateInquiry();
  
  const form = useForm<InsertInquiry>({
    resolver: zodResolver(insertInquirySchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      productInterest: "",
      message: "",
    },
  });

  const onSubmit = (data: InsertInquiry) => {
    mutation.mutate(data, {
      onSuccess: () => {
        form.reset();
      }
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      {/* Hero */}
      <section className="bg-primary text-primary-foreground py-20 lg:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://pixabay.com/get/g1f61fff79bfdf1d6ba2f46095fe44a7997317b1dd200568a715d4281a59427e03820bf64cc9a0f8abfb176058f89102ff1f735b50f145ec843bba207086fcdda_1280.jpg')] bg-cover bg-center opacity-10 mix-blend-overlay" />
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="font-display text-4xl lg:text-6xl font-bold mb-6">Wholesale & Industrial</h1>
          <p className="text-lg lg:text-xl text-primary-foreground/80 max-w-2xl mx-auto">
            Partner with us for consistent, high-quality coconut ingredients. 
            From bulk oil to desiccated coconut, we supply the food industry globally.
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16 grid lg:grid-cols-2 gap-16">
        {/* Value Prop */}
        <div className="space-y-12">
          <div>
            <h2 className="font-display text-3xl font-bold mb-6 text-primary">Why Partner With CocoLife?</h2>
            <p className="text-muted-foreground">
              We own the entire supply chain, ensuring traceability from tree to table. 
              Our processing facilities are ISO 22000 certified and meet international export standards.
            </p>
          </div>

          <div className="space-y-8">
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center text-yellow-700 flex-shrink-0">
                <Globe2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Global Logistics</h3>
                <p className="text-sm text-muted-foreground">Shipping to over 40 countries with reliable freight partners.</p>
              </div>
            </div>
            
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                <Leaf className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Consistent Quality</h3>
                <p className="text-sm text-muted-foreground">Strict QC measures ensuring standardized acidity, moisture, and fat content.</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-secondary/20 flex items-center justify-center text-primary flex-shrink-0">
                <Package className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Bulk Formatting</h3>
                <p className="text-sm text-muted-foreground">Available in 200L drums, 1000L IBC totes, and flexi-tanks.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="bg-card p-8 rounded-3xl border border-border shadow-lg shadow-black/5">
          <h3 className="font-display text-2xl font-bold mb-6">Request a Quote</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Email</FormLabel>
                    <FormControl>
                      <Input placeholder="john@company.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company</FormLabel>
                      <FormControl>
                        <Input placeholder="Company Inc." {...field} value={field.value || ''} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="productInterest"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Interested In</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value || undefined}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Product" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="bulk_oil">Bulk Virgin Oil</SelectItem>
                          <SelectItem value="bulk_milk">Bulk Coconut Milk</SelectItem>
                          <SelectItem value="desiccated">Desiccated Coconut</SelectItem>
                          <SelectItem value="shell_charcoal">Shell Charcoal</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Tell us about your volume requirements..." 
                        className="min-h-[120px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full h-12 text-base" disabled={mutation.isPending}>
                {mutation.isPending ? "Sending..." : "Submit Inquiry"}
              </Button>
            </form>
          </Form>
        </div>
      </div>

      <Footer />
    </div>
  );
}
