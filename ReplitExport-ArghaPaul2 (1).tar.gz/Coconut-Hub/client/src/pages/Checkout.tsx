import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useCreateOrder } from "@/hooks/use-orders";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Link, useLocation } from "wouter";
import { Lock } from "lucide-react";

export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const mutation = useCreateOrder();
  const [, setLocation] = useLocation();

  const handlePlaceOrder = () => {
    const orderData = {
      items: items.map(item => ({
        productId: item.id,
        quantity: item.quantity
      }))
    };

    mutation.mutate(orderData, {
      onSuccess: () => {
        clearCart();
        setLocation("/profile"); // Redirect to history
      }
    });
  };

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="flex-1 flex flex-col items-center justify-center space-y-4">
          <h2 className="text-2xl font-bold">Your cart is empty</h2>
          <Button asChild><Link href="/products">Continue Shopping</Link></Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary/5 flex flex-col">
      <Navigation />

      <main className="container mx-auto px-4 py-12 flex-1">
        <h1 className="font-display text-3xl font-bold mb-8">Checkout</h1>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left: Details */}
          <div className="space-y-8">
            <div className="bg-card p-6 rounded-2xl border">
              <h2 className="text-xl font-bold mb-4">1. Contact Information</h2>
              {isAuthenticated ? (
                <div className="flex items-center gap-3 bg-secondary/10 p-4 rounded-lg">
                  <div className="h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                    {user?.firstName?.[0]}
                  </div>
                  <div>
                    <p className="font-medium">{user?.firstName} {user?.lastName}</p>
                    <p className="text-sm text-muted-foreground">{user?.email}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                   <p className="text-sm text-muted-foreground mb-2">Login to save your order history and checkout faster.</p>
                   <Button asChild variant="outline" className="w-full">
                     <a href="/api/login">Login with Replit</a>
                   </Button>
                </div>
              )}
            </div>

            <div className="bg-card p-6 rounded-2xl border">
              <h2 className="text-xl font-bold mb-4">2. Shipping Address</h2>
              <form className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label>Address</Label>
                  <Input placeholder="123 Coconut Lane" />
                </div>
                <div>
                  <Label>City</Label>
                  <Input placeholder="Palm Beach" />
                </div>
                <div>
                  <Label>Postal Code</Label>
                  <Input placeholder="90210" />
                </div>
              </form>
            </div>

            <div className="bg-card p-6 rounded-2xl border">
              <h2 className="text-xl font-bold mb-4">3. Payment</h2>
              <div className="bg-secondary/10 p-4 rounded-lg flex items-center gap-3 text-sm text-muted-foreground">
                <Lock className="w-4 h-4" />
                <span>This is a demo checkout. No payment will be processed.</span>
              </div>
            </div>
          </div>

          {/* Right: Summary */}
          <div className="lg:sticky lg:top-24 h-fit">
            <div className="bg-card p-6 rounded-2xl border shadow-lg shadow-black/5">
              <h2 className="text-xl font-bold mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="h-16 w-16 bg-secondary/10 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={item.imageUrl} alt={item.name} className="h-full w-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <span className="font-medium line-clamp-1">{item.name}</span>
                        <span>{formatPrice(item.price * item.quantity)}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">Qty: {item.quantity}</span>
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="mb-4" />

              <div className="space-y-2 mb-6">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatPrice(total())}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>Free</span>
                </div>
                <div className="flex justify-between text-lg font-bold text-primary pt-2">
                  <span>Total</span>
                  <span>{formatPrice(total())}</span>
                </div>
              </div>

              <Button 
                className="w-full h-12 text-lg" 
                onClick={handlePlaceOrder}
                disabled={!isAuthenticated || mutation.isPending}
              >
                {mutation.isPending ? "Processing..." : "Place Order"}
              </Button>
              {!isAuthenticated && (
                <p className="text-xs text-center text-destructive mt-2">
                  Please login to complete your order.
                </p>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
