import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, CheckCircle2, Factory, Leaf, Sprout } from "lucide-react";
import { motion } from "framer-motion";
import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";

export default function Home() {
  const { data: products, isLoading } = useProducts();
  const featuredProducts = products?.slice(0, 4);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground min-h-[80vh] flex items-center">
        {/* Abstract Background Shapes */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-secondary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-accent/10 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4" />
        </div>

        <div className="container mx-auto px-4 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20">
              <span className="h-2 w-2 rounded-full bg-accent animate-pulse" />
              <span className="text-sm font-medium tracking-wide">Nature's Perfect Alternative</span>
            </div>
            
            <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight">
              Pure Coconut <br />
              <span className="text-accent italic">Goodness.</span>
            </h1>
            
            <p className="text-lg md:text-xl text-primary-foreground/80 max-w-lg leading-relaxed">
              Ethically sourced, organic coconut products for a healthier life. 
              The perfect dairy-free solution for your gut health.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" className="rounded-full h-14 px-8 text-base bg-accent text-accent-foreground hover:bg-accent/90" asChild>
                <Link href="/products">Shop Collection</Link>
              </Button>
              <Button size="lg" variant="outline" className="rounded-full h-14 px-8 text-base border-white/30 hover:bg-white/10 text-white" asChild>
                <Link href="/b2b">Wholesale Inquiry</Link>
              </Button>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative lg:h-[600px] flex items-center justify-center"
          >
            {/* Using Unsplash image for coconut hero */}
            {/* coconut drink on tropical background */}
            <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-2xl shadow-black/20 rotate-3 hover:rotate-0 transition-transform duration-700 ease-out border-4 border-white/10 w-full max-w-md aspect-[3/4]">
              <img 
                src="https://images.unsplash.com/photo-1550583724-b2692b85b150?w=800&q=80" 
                alt="Fresh Coconut Milk" 
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Lactose Intolerance Story */}
      <section className="py-24 bg-white relative">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="font-display text-4xl font-bold text-primary">Happy Gut, Happy Life</h2>
            <p className="text-muted-foreground text-lg">
              For millions dealing with lactose intolerance, coconut milk isn't just an alternative—it's a lifestyle upgrade. 
              Rich, creamy, and naturally gentle on your stomach.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-3xl bg-secondary/10 border border-secondary/20 hover:border-secondary/50 transition-colors">
              <div className="h-12 w-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 text-primary">
                <Leaf className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">100% Dairy Free</h3>
              <p className="text-muted-foreground">
                Naturally free from lactose and casein. No bloating, no discomfort—just pure plant-based nutrition.
              </p>
            </div>

            <div className="p-8 rounded-3xl bg-accent/10 border border-accent/20 hover:border-accent/50 transition-colors">
              <div className="h-12 w-12 bg-accent/20 rounded-2xl flex items-center justify-center mb-6 text-yellow-700">
                <Sprout className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">MCT Rich Energy</h3>
              <p className="text-muted-foreground">
                Packed with Medium Chain Triglycerides (MCTs) for sustained energy release without the crash.
              </p>
            </div>

            <div className="p-8 rounded-3xl bg-primary/5 border border-primary/10 hover:border-primary/30 transition-colors">
              <div className="h-12 w-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 text-primary">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Clean Ingredients</h3>
              <p className="text-muted-foreground">
                No gums, no fillers, no artificial additives. Just organic coconut meat and purified water.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-secondary/5">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="font-display text-3xl font-bold mb-2">Customer Favorites</h2>
              <p className="text-muted-foreground">Our most loved coconut essentials.</p>
            </div>
            <Link href="/products" className="hidden md:flex items-center gap-2 text-primary font-medium hover:underline">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-96 bg-gray-100 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="mt-12 text-center md:hidden">
            <Button variant="outline" className="rounded-full" asChild>
              <Link href="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* B2B Banner */}
      <section className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
         {/* industrial coconut factory abstract */}
        <div className="absolute inset-0 opacity-10">
          <img 
            src="https://pixabay.com/get/g6f928b222663d5c4176c61456a5ae60f5db694857883ad2213f31f78b19b256ae455f99d18ef9782984b9d36d150ebc71c762cf227869a6cf9be896cd2d7730f_1280.jpg" 
            alt="Coconut Farm" 
            className="w-full h-full object-cover grayscale"
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl bg-primary/80 backdrop-blur p-8 md:p-12 rounded-3xl border border-white/10">
            <div className="flex items-center gap-3 mb-6">
              <Factory className="w-8 h-8 text-accent" />
              <span className="font-mono text-accent tracking-widest uppercase text-sm">Industrial & Wholesale</span>
            </div>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">Scale Your Business with Premium Ingredients</h2>
            <p className="text-lg text-primary-foreground/80 mb-8">
              We supply bulk coconut milk, oil, and by-products to manufacturers and food service providers worldwide. Consistent quality, reliable logistics.
            </p>
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 rounded-full" asChild>
              <Link href="/b2b">Partner With Us</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
