import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="font-display text-2xl font-bold">CocoLife</h3>
            <p className="text-primary-foreground/80 leading-relaxed">
              Bringing the purest, organic coconut products from our sustainable farms to your home.
            </p>
          </div>

          {/* Shop */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg">Shop</h4>
            <ul className="space-y-2">
              <li><Link href="/products?category=coconut_milk" className="hover:text-accent transition-colors">Coconut Milk</Link></li>
              <li><Link href="/products?category=coconut_oil" className="hover:text-accent transition-colors">Organic Oil</Link></li>
              <li><Link href="/products?category=coconut_meat" className="hover:text-accent transition-colors">Coconut Meat</Link></li>
              <li><Link href="/products" className="hover:text-accent transition-colors">All Products</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg">Company</h4>
            <ul className="space-y-2">
              <li><Link href="/b2b" className="hover:text-accent transition-colors">B2B / Wholesale</Link></li>
              <li><Link href="#" className="hover:text-accent transition-colors">Sustainability</Link></li>
              <li><Link href="#" className="hover:text-accent transition-colors">Our Story</Link></li>
              <li><Link href="#" className="hover:text-accent transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg">Stay Fresh</h4>
            <p className="text-sm text-primary-foreground/80">Subscribe for recipes and wellness tips.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-primary-foreground/10 border border-primary-foreground/20 rounded px-3 py-2 text-sm w-full placeholder:text-primary-foreground/50 focus:outline-none focus:border-accent"
              />
              <button className="bg-accent text-accent-foreground px-4 py-2 rounded font-semibold hover:brightness-110 transition-all">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 pt-8 text-center text-sm text-primary-foreground/60">
          <p>&copy; {new Date().getFullYear()} CocoLife Inc. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
