import { type Product } from "@shared/schema";
import { Link } from "wouter";
import { Button } from "./ui/button";
import { useCart } from "@/hooks/use-cart";
import { ShoppingBag, Eye } from "lucide-react";
import { Badge } from "./ui/badge";

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const categoryLabel = product.category.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');

  return (
    <div className="group bg-card rounded-2xl border border-border/50 overflow-hidden hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 flex flex-col h-full">
      {/* Image Container */}
      <div className="relative aspect-square bg-secondary/10 overflow-hidden">
        <Link href={`/products/${product.id}`}>
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
        </Link>
        {product.isB2BOnly && (
          <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground">
            B2B Only
          </Badge>
        )}
        
        {/* Quick Actions Overlay */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full shadow-lg"
            onClick={() => addItem(product)}
            disabled={product.isB2BOnly}
          >
            <ShoppingBag className="h-4 w-4" />
          </Button>
          <Link href={`/products/${product.id}`}>
            <Button size="icon" variant="secondary" className="rounded-full shadow-lg">
              <Eye className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-grow">
        <div className="mb-2">
          <span className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
            {categoryLabel}
          </span>
        </div>
        <Link href={`/products/${product.id}`} className="block mb-2">
          <h3 className="font-display text-lg font-bold text-foreground group-hover:text-primary transition-colors">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-grow">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/50">
          <span className="font-mono font-medium text-lg text-primary">
            {formatPrice(product.price)}
          </span>
          <Button 
            onClick={() => addItem(product)} 
            disabled={product.isB2BOnly}
            variant="outline"
            className="rounded-full hover:bg-primary hover:text-primary-foreground border-primary/20"
          >
            {product.isB2BOnly ? "Bulk Inquiry" : "Add to Cart"}
          </Button>
        </div>
      </div>
    </div>
  );
}
