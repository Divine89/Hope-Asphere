## Packages
framer-motion | Complex animations for page transitions and scroll reveals
zustand | Lightweight global state management for the shopping cart
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["DM Sans", "sans-serif"],
  display: ["Playfair Display", "serif"],
}
