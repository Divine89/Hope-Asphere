import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // Products
  app.get(api.products.list.path, async (req, res) => {
    const category = req.query.category as string | undefined;
    const products = await storage.getProducts(category);
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  });

  // Inquiries
  app.post(api.inquiries.create.path, async (req, res) => {
    try {
      const input = api.inquiries.create.input.parse(req.body);
      const inquiry = await storage.createInquiry(input);
      res.status(201).json(inquiry);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Orders
  app.post(api.orders.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.orders.create.input.parse(req.body);
      const userId = req.user?.claims?.sub; // From Replit Auth
      const order = await storage.createOrder(userId, input.items);
      res.status(201).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.orders.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user?.claims?.sub;
    const orders = await storage.getOrders(userId);
    res.json(orders);
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingProducts = await storage.getProducts();
  if (existingProducts.length === 0) {
    const products = [
      {
        name: "Premium Coconut Milk",
        description: "Rich, creamy, and 100% organic. Perfect for lactose intolerant diets.",
        category: "coconut_milk",
        price: 499, // $4.99
        imageUrl: "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&q=80&w=1000",
        stock: 100,
      },
      {
        name: "Virgin Coconut Oil",
        description: "Cold-pressed virgin coconut oil. Use it for healthy cooking, natural skin hydration, or as a nourishing hair treatment.",
        category: "coconut_oil",
        price: 1299, // $12.99
        imageUrl: "/src/assets/products/virgin-oil.jpg",
        stock: 50,
      },
      {
        name: "Dry Coconut Husk Powder",
        description: "Finely ground dry coconut husk. Excellent as a soil conditioner, natural abrasive for cleaning, or sustainable industrial filler.",
        category: "coconut_husk",
        price: 899, // $8.99
        imageUrl: "/src/assets/products/husk-powder.jpg",
        stock: 200,
      },
      {
        name: "Coconut Flesh",
        description: "Crisp, white coconut flesh, ready for culinary use or snacking.",
        category: "coconut_meat",
        price: 399, // $3.99
        imageUrl: "/src/assets/products/coconut-flesh.jpg",
        stock: 30,
      },
      {
        name: "Activated Coconut Charcoal",
        description: "Made from coconut pits, great for detoxification.",
        category: "coconut_pit",
        price: 1599, // $15.99
        imageUrl: "https://images.unsplash.com/photo-1543364195-077a16c30ff3?auto=format&fit=crop&q=80&w=1000",
        stock: 150,
      }
    ];

    for (const p of products) {
      await storage.createProduct(p);
    }
  }
}
