import { db } from "./db";
import {
  products,
  inquiries,
  orders,
  orderItems,
  users,
  type Product,
  type InsertProduct,
  type Inquiry,
  type InsertInquiry,
  type Order,
  type InsertOrder,
  type CreateOrderRequest,
  type User
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { authStorage } from "./replit_integrations/auth/storage";

export interface IStorage {
  // Auth
  getUser(id: string): Promise<User | undefined>;

  // Products
  getProducts(category?: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Inquiries
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;

  // Orders
  createOrder(userId: string | null, items: { productId: number; quantity: number }[]): Promise<Order>;
  getOrders(userId: string): Promise<Order[]>;
}

export class DatabaseStorage implements IStorage {
  // Auth delegates to authStorage
  async getUser(id: string): Promise<User | undefined> {
    return authStorage.getUser(id);
  }

  // Products
  async getProducts(category?: string): Promise<Product[]> {
    if (category) {
      return await db.select().from(products).where(eq(products.category, category));
    }
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  // Inquiries
  async createInquiry(inquiry: InsertInquiry): Promise<Inquiry> {
    const [newInquiry] = await db.insert(inquiries).values(inquiry).returning();
    return newInquiry;
  }

  // Orders
  async createOrder(userId: string | null, items: { productId: number; quantity: number }[]): Promise<Order> {
    // Calculate total and verify stock
    let total = 0;
    const orderItemsData: { productId: number; quantity: number; price: number }[] = [];

    for (const item of items) {
      const product = await this.getProduct(item.productId);
      if (!product) throw new Error(`Product ${item.productId} not found`);
      // In a real app, check stock here
      total += product.price * item.quantity;
      orderItemsData.push({
        productId: item.productId,
        quantity: item.quantity,
        price: product.price,
      });
    }

    // Create order
    const [order] = await db.insert(orders).values({
      userId: userId || null,
      total,
      status: "pending",
    }).returning();

    // Create order items
    if (orderItemsData.length > 0) {
      await db.insert(orderItems).values(
        orderItemsData.map((item) => ({
          orderId: order.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
        }))
      );
    }

    return order;
  }

  async getOrders(userId: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }
}

export const storage = new DatabaseStorage();
