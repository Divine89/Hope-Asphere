import talib
import numpy as np

def momentum_score(close):
    rsi = talib.RSI(close, 14)
    macd, signal, hist = talib.MACD(close)
    roc = talib.ROC(close, 10)

    score = 0
    score += 1 if rsi[-1] > 55 else 0
    score += 1 if hist[-1] > 0 else 0
    score += 1 if roc[-1] > 0 else 0
    return score

def atr_percent(high, low, close):
    atr = talib.ATR(high, low, close, 14)
    return atr[-1] / close[-1]
