import ccxt
from config import BINANCE_API_KEY, BINANCE_API_SECRET

exchange = ccxt.binance({
    "apiKey": BINANCE_API_KEY,
    "secret": BINANCE_API_SECRET,
    "enableRateLimit": True,
    "options": {"defaultType": "future"}
})

def get_futures_symbols():
    markets = exchange.load_markets()
    return [
        s for s in markets
        if s.endswith("USDT") and markets[s]["future"]
    ]

balance = exchange.fetch_balance()
print(balance["USDT"]["free"])
