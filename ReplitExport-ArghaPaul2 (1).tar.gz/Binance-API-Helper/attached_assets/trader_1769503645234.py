from exchange import exchange

def open_position(symbol, side, qty):
    order = exchange.create_market_order(
        symbol=symbol,
        side=side,
        amount=qty
    )
    return order

def close_position(symbol, qty, side):
    exchange.create_market_order(
        symbol=symbol,
        side=side,
        amount=qty
    )
