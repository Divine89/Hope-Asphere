import json
import websockets
import asyncio

prices = {}

async def price_stream(symbols):
    streams = "/".join([f"{s.lower()}@markPrice" for s in symbols])
    url = f"wss://fstream.binance.com/stream?streams={streams}"

    async with websockets.connect(url) as ws:
        while True:
            data = json.loads(await ws.recv())
            symbol = data["data"]["s"]
            price = float(data["data"]["p"])
            prices[symbol] = price
