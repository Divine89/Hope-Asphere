def position_size(balance, price, atr_pct, risk_pct):
    risk_amount = balance * risk_pct
    stop_distance = price * atr_pct
    qty = risk_amount / stop_distance
    return qty
