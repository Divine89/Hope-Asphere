import pandas as pd
from exchange import exchange, get_futures_symbols
from strategy import expected_outcome
from risk import position_size
from trader import open_position

def fetch_ohlcv(symbol):
    ohlcv = exchange.fetch_ohlcv(symbol, "15m", limit=100)
    return pd.DataFrame(
        ohlcv,
        columns=["ts", "open", "high", "low", "close", "volume"]
    )

def run():
    symbols = get_futures_symbols()
    btc_df = fetch_ohlcv("BTC/USDT")

    best_pair = None
    best_eov = 0

    for s in symbols:
        try:
            df = fetch_ohlcv(s)
            eov, corr = expected_outcome(df, btc_df)

            if eov > best_eov:
                best_eov = eov
                best_pair = s
        except:
            continue

    if best_pair:
        balance = exchange.fetch_balance()["USDT"]["free"]
        price = exchange.fetch_ticker(best_pair)["last"]
        qty = position_size(balance, price, 0.01, 0.01)

        open_position(best_pair, "buy", qty)
        print(f"Entered LONG on {best_pair}")

if __name__ == "__main__":
    run()
