import numpy as np
import pandas as pd
from indicators import momentum_score, atr_percent

def correlation(a, b):
    return np.corrcoef(a, b)[0, 1]

def expected_outcome(pair_df, btc_df):
    corr = correlation(pair_df["close"], btc_df["close"])
    momentum = momentum_score(pair_df["close"].values)
    vol = atr_percent(
        pair_df["high"].values,
        pair_df["low"].values,
        pair_df["close"].values
    )

    eov = momentum * corr * vol
    return eov, corr
