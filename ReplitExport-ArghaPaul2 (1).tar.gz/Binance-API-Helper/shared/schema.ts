import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Settings for the bot
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  riskPerTrade: real("risk_per_trade").default(0.01).notNull(),
  timeframe: text("timeframe").default("15m").notNull(),
  tradingEnabled: boolean("trading_enabled").default(false).notNull(),
  symbols: text("symbols").array().default(["BTC/USDT", "ETH/USDT"]).notNull(),
});

// Trade history
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // 'buy' or 'sell'
  entryPrice: real("entry_price").notNull(),
  exitPrice: real("exit_price"),
  quantity: real("quantity").notNull(),
  status: text("status").notNull(), // 'open', 'closed'
  pnl: real("pnl"),
  openedAt: timestamp("opened_at").defaultNow().notNull(),
  closedAt: timestamp("closed_at"),
});

// System logs
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  level: text("level").notNull(), // 'info', 'warn', 'error', 'success'
  message: text("message").notNull(),
  data: jsonb("data"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertSettingsSchema = createInsertSchema(settings);
export const insertTradeSchema = createInsertSchema(trades);
export const insertLogSchema = createInsertSchema(logs);

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;
