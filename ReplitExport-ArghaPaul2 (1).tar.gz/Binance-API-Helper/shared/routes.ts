import { z } from 'zod';
import { insertSettingsSchema, insertTradeSchema, insertLogSchema, trades, logs, settings } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  settings: {
    get: {
      method: 'GET' as const,
      path: '/api/settings',
      responses: {
        200: z.custom<typeof settings.$inferSelect>(),
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/settings',
      input: insertSettingsSchema.partial(),
      responses: {
        200: z.custom<typeof settings.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  bot: {
    status: {
      method: 'GET' as const,
      path: '/api/bot/status',
      responses: {
        200: z.object({
          isRunning: z.boolean(),
          uptime: z.number(),
          balance: z.object({
            free: z.number(),
            total: z.number(),
            currency: z.string(),
          }).optional(),
        }),
      },
    },
    start: {
      method: 'POST' as const,
      path: '/api/bot/start',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    stop: {
      method: 'POST' as const,
      path: '/api/bot/stop',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
  },
  trades: {
    list: {
      method: 'GET' as const,
      path: '/api/trades',
      input: z.object({
        limit: z.string().optional(),
        status: z.enum(['open', 'closed']).optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof trades.$inferSelect>()),
      },
    },
  },
  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs',
      input: z.object({
        limit: z.string().optional(),
        level: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof logs.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
