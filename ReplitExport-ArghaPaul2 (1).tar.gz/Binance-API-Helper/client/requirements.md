## Packages
recharts | For visualizing PnL or balance trends (if needed later, good to have)
date-fns | For formatting timestamps in logs and trades

## Notes
Polling is required for logs and status as per implementation notes (2s interval).
Dark mode is mandatory for the financial dashboard aesthetic.
Font: 'JetBrains Mono' for logs/code, 'Inter' for UI.
