import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertSettings } from "@shared/routes";

// ============================================
// BOT STATUS
// ============================================
export function useBotStatus() {
  return useQuery({
    queryKey: [api.bot.status.path],
    queryFn: async () => {
      const res = await fetch(api.bot.status.path);
      if (!res.ok) throw new Error("Failed to fetch bot status");
      return api.bot.status.responses[200].parse(await res.json());
    },
    refetchInterval: 2000, // Poll every 2s
  });
}

export function useStartBot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.bot.start.path, { method: api.bot.start.method });
      if (!res.ok) throw new Error("Failed to start bot");
      return api.bot.start.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bot.status.path] });
      queryClient.invalidateQueries({ queryKey: [api.logs.list.path] });
    },
  });
}

export function useStopBot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.bot.stop.path, { method: api.bot.stop.method });
      if (!res.ok) throw new Error("Failed to stop bot");
      return api.bot.stop.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bot.status.path] });
      queryClient.invalidateQueries({ queryKey: [api.logs.list.path] });
    },
  });
}

// ============================================
// SETTINGS
// ============================================
export function useSettings() {
  return useQuery({
    queryKey: [api.settings.get.path],
    queryFn: async () => {
      const res = await fetch(api.settings.get.path);
      if (!res.ok) throw new Error("Failed to fetch settings");
      return api.settings.get.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateSettings() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (updates: Partial<InsertSettings>) => {
      const validated = api.settings.update.input.parse(updates);
      const res = await fetch(api.settings.update.path, {
        method: api.settings.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) {
        if (res.status === 400) {
          throw new Error("Invalid settings provided");
        }
        throw new Error("Failed to update settings");
      }
      return api.settings.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.settings.get.path] });
    },
  });
}

// ============================================
// TRADES
// ============================================
export function useTrades(params?: { limit?: string; status?: 'open' | 'closed' }) {
  return useQuery({
    queryKey: [api.trades.list.path, params],
    queryFn: async () => {
      const url = new URL(api.trades.list.path, window.location.origin);
      if (params?.limit) url.searchParams.set("limit", params.limit);
      if (params?.status) url.searchParams.set("status", params.status);
      
      const res = await fetch(url.toString());
      if (!res.ok) throw new Error("Failed to fetch trades");
      return api.trades.list.responses[200].parse(await res.json());
    },
    refetchInterval: 5000,
  });
}

// ============================================
// LOGS
// ============================================
export function useLogs(limit: string = "100") {
  return useQuery({
    queryKey: [api.logs.list.path, limit],
    queryFn: async () => {
      const url = new URL(api.logs.list.path, window.location.origin);
      url.searchParams.set("limit", limit);
      
      const res = await fetch(url.toString());
      if (!res.ok) throw new Error("Failed to fetch logs");
      return api.logs.list.responses[200].parse(await res.json());
    },
    refetchInterval: 2000,
  });
}
