import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase } from "lucide-react";
import type { Trade } from "@shared/schema";
import { format } from "date-fns";

interface TradesTableProps {
  trades: Trade[];
}

export function TradesTable({ trades }: TradesTableProps) {
  return (
    <Card className="h-full bg-card/50 backdrop-blur-sm border-border/50 shadow-lg flex flex-col">
      <CardHeader>
        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
          <Briefcase className="w-4 h-4" /> Trade History
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-auto p-0">
        <div className="max-h-[300px] overflow-auto custom-scrollbar">
          <Table>
            <TableHeader className="sticky top-0 bg-card/95 backdrop-blur z-10">
              <TableRow className="border-border/50 hover:bg-transparent">
                <TableHead className="w-[100px]">Symbol</TableHead>
                <TableHead>Side</TableHead>
                <TableHead>Entry</TableHead>
                <TableHead>Exit</TableHead>
                <TableHead>Qty</TableHead>
                <TableHead className="text-right">PnL (USDT)</TableHead>
                <TableHead className="text-right">Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {trades.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                    No trades recorded yet.
                  </TableCell>
                </TableRow>
              ) : (
                trades.map((trade) => (
                  <TableRow key={trade.id} className="border-border/50 hover:bg-muted/50 font-mono text-xs">
                    <TableCell className="font-bold text-foreground">{trade.symbol}</TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={
                          trade.side === 'buy' 
                            ? "border-success/30 text-success bg-success/10" 
                            : "border-danger/30 text-danger bg-danger/10"
                        }
                      >
                        {trade.side.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell>{trade.entryPrice.toFixed(2)}</TableCell>
                    <TableCell>{trade.exitPrice?.toFixed(2) || '-'}</TableCell>
                    <TableCell>{trade.quantity}</TableCell>
                    <TableCell className={`text-right font-medium ${
                      (trade.pnl || 0) > 0 ? "text-success" : (trade.pnl || 0) < 0 ? "text-danger" : "text-muted-foreground"
                    }`}>
                      {trade.pnl ? `${trade.pnl > 0 ? '+' : ''}${trade.pnl.toFixed(2)}` : '-'}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {format(new Date(trade.openedAt), "HH:mm:ss dd/MM")}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
