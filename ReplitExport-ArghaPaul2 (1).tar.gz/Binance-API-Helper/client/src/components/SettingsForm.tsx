import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings } from "lucide-react";
import { useEffect } from "react";
import type { Settings as SettingsType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  riskPerTrade: z.coerce.number().min(0.1).max(100),
  timeframe: z.string(),
  symbols: z.string().transform((str) => str.split(",").map((s) => s.trim())),
});

interface SettingsFormProps {
  settings?: SettingsType;
  onSave: (data: Partial<SettingsType>) => void;
  isSaving: boolean;
}

export function SettingsForm({ settings, onSave, isSaving }: SettingsFormProps) {
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      riskPerTrade: 1.0,
      timeframe: "15m",
      symbols: "BTC/USDT, ETH/USDT",
    },
  });

  // Update form when settings load
  useEffect(() => {
    if (settings) {
      form.reset({
        riskPerTrade: settings.riskPerTrade * 100, // Convert to percentage
        timeframe: settings.timeframe,
        symbols: settings.symbols.join(", "),
      });
    }
  }, [settings, form]);

  function onSubmit(values: z.infer<typeof formSchema>) {
    onSave({
      riskPerTrade: values.riskPerTrade / 100, // Convert back to decimal
      timeframe: values.timeframe,
      symbols: values.symbols,
    });
    toast({
      title: "Settings Saved",
      description: "Bot configuration has been updated successfully.",
    });
  }

  return (
    <Card className="h-full bg-card/50 backdrop-blur-sm border-border/50 shadow-lg">
      <CardHeader>
        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
          <Settings className="w-4 h-4" /> Configuration
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="riskPerTrade"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Risk per Trade (%)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.1" {...field} className="bg-background/50 font-mono" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="timeframe"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Timeframe</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-background/50 font-mono">
                        <SelectValue placeholder="Select timeframe" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1m">1m</SelectItem>
                      <SelectItem value="5m">5m</SelectItem>
                      <SelectItem value="15m">15m</SelectItem>
                      <SelectItem value="1h">1h</SelectItem>
                      <SelectItem value="4h">4h</SelectItem>
                      <SelectItem value="1d">1d</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="symbols"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Symbols (comma separated)</FormLabel>
                  <FormControl>
                    <Input {...field} className="bg-background/50 font-mono" placeholder="BTC/USDT, ETH/USDT" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" disabled={isSaving} className="w-full bg-primary/20 text-primary hover:bg-primary/30 border border-primary/20">
              {isSaving ? "Saving..." : "Apply Settings"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
