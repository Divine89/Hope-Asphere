import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Terminal } from "lucide-react";
import type { Log } from "@shared/schema";
import { format } from "date-fns";

interface LogsTerminalProps {
  logs: Log[];
}

export function LogsTerminal({ logs }: LogsTerminalProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs]);

  const getLogColor = (level: string) => {
    switch (level) {
      case "error": return "text-danger";
      case "warn": return "text-warning";
      case "success": return "text-success";
      default: return "text-muted-foreground";
    }
  };

  return (
    <Card className="h-full bg-black/40 backdrop-blur-md border-border/50 shadow-lg flex flex-col font-mono">
      <CardHeader className="py-3 border-b border-white/5 bg-white/5">
        <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-2">
          <Terminal className="w-3 h-3" /> SYSTEM LOGS
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0 relative">
        <div className="absolute inset-0 p-4 overflow-auto custom-scrollbar space-y-1">
          {logs.length === 0 && (
            <div className="text-muted-foreground/50 text-xs italic">Awaiting system events...</div>
          )}
          {logs.map((log) => (
            <div key={log.id} className="text-xs flex gap-2">
              <span className="text-muted-foreground/40 shrink-0">
                [{format(new Date(log.timestamp), "HH:mm:ss")}]
              </span>
              <span className={`uppercase font-bold shrink-0 w-16 ${getLogColor(log.level)}`}>
                {log.level}
              </span>
              <span className="text-foreground/80 break-all">
                {log.message}
              </span>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
      </CardContent>
    </Card>
  );
}
