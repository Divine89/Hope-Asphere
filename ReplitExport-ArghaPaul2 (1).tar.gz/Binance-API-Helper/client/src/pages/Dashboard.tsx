import { useBotStatus, useLogs, useSettings, useStartBot, useStopBot, useTrades, useUpdateSettings } from "@/hooks/use-dashboard";
import { StatusCard } from "@/components/StatusCard";
import { SettingsForm } from "@/components/SettingsForm";
import { TradesTable } from "@/components/TradesTable";
import { LogsTerminal } from "@/components/LogsTerminal";
import { Button } from "@/components/ui/button";
import { Play, Square } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { data: status, isLoading: statusLoading } = useBotStatus();
  const { data: settings } = useSettings();
  const { data: trades } = useTrades();
  const { data: logs } = useLogs();
  
  const startBot = useStartBot();
  const stopBot = useStopBot();
  const updateSettings = useUpdateSettings();
  const { toast } = useToast();

  const handleStartStop = () => {
    if (status?.isRunning) {
      stopBot.mutate(undefined, {
        onSuccess: () => toast({ title: "Bot Stopped", description: "Trading has been paused." }),
        onError: (e) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      });
    } else {
      startBot.mutate(undefined, {
        onSuccess: () => toast({ title: "Bot Started", description: "Trading engine is now active." }),
        onError: (e) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      });
    }
  };

  if (statusLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
          <p className="text-muted-foreground font-mono animate-pulse">Initializing Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8 space-y-6 bg-grid-pattern relative overflow-hidden">
      {/* Background glow effects */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[128px] pointer-events-none" />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-[128px] pointer-events-none" />

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <span className="text-primary">⚡</span> QUANT DASHBOARD
          </h1>
          <p className="text-muted-foreground text-sm">Automated Trading Control Center</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="hidden md:block text-right">
            <p className="text-xs text-muted-foreground uppercase tracking-widest">Net Equity</p>
            <p className="text-xl font-mono font-bold text-foreground">
              {status?.balance?.total?.toFixed(2) ?? "0.00"} <span className="text-sm text-muted-foreground">USDT</span>
            </p>
          </div>
          
          <Button 
            size="lg"
            variant={status?.isRunning ? "destructive" : "default"}
            className={`font-semibold shadow-lg transition-all ${
              status?.isRunning 
                ? "shadow-danger/20 hover:shadow-danger/40" 
                : "bg-gradient-to-r from-primary to-primary/80 shadow-primary/20 hover:shadow-primary/40"
            }`}
            onClick={handleStartStop}
            disabled={startBot.isPending || stopBot.isPending}
          >
            {startBot.isPending || stopBot.isPending ? (
              "Processing..."
            ) : status?.isRunning ? (
              <><Square className="mr-2 h-4 w-4 fill-current" /> STOP ENGINE</>
            ) : (
              <><Play className="mr-2 h-4 w-4 fill-current" /> START ENGINE</>
            )}
          </Button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10 h-[calc(100vh-140px)] min-h-[600px]">
        {/* Left Column - Status & Settings */}
        <div className="space-y-6 lg:col-span-1 flex flex-col h-full">
          <div className="h-1/3">
            <StatusCard 
              isRunning={!!status?.isRunning} 
              uptime={status?.uptime || 0}
              balance={status?.balance} 
            />
          </div>
          <div className="h-2/3">
            <SettingsForm 
              settings={settings} 
              onSave={(data) => updateSettings.mutate(data)}
              isSaving={updateSettings.isPending}
            />
          </div>
        </div>

        {/* Center/Right - Trades & Logs */}
        <div className="md:col-span-2 space-y-6 flex flex-col h-full">
          <div className="h-1/2">
            <TradesTable trades={trades || []} />
          </div>
          <div className="h-1/2">
            <LogsTerminal logs={logs || []} />
          </div>
        </div>
      </main>
    </div>
  );
}
