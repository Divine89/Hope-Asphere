import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { TradingBot } from "./bot"; // We will create this next

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const bot = new TradingBot(storage);

  // Settings
  app.get(api.settings.get.path, async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.patch(api.settings.update.path, async (req, res) => {
    try {
      const input = api.settings.update.input.parse(req.body);
      const updated = await storage.updateSettings(input);
      // Update bot config in real-time
      bot.updateConfig(updated);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Bot Control
  app.get(api.bot.status.path, async (req, res) => {
    const status = await bot.getStatus();
    res.json(status);
  });

  app.post(api.bot.start.path, async (req, res) => {
    try {
      await bot.start();
      res.json({ message: "Bot started" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post(api.bot.stop.path, async (req, res) => {
    await bot.stop();
    res.json({ message: "Bot stopped" });
  });

  // Trades
  app.get(api.trades.list.path, async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const status = req.query.status as string | undefined;
    const trades = await storage.getTrades(limit, status);
    res.json(trades);
  });

  // Logs
  app.get(api.logs.list.path, async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
    const level = req.query.level as string | undefined;
    const logs = await storage.getLogs(limit, level);
    res.json(logs);
  });

  return httpServer;
}
