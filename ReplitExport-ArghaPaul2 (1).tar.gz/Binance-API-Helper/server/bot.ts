import ccxt from 'ccxt';
import { IStorage } from './storage';
import { RSI, MACD, ROC, ATR } from 'technicalindicators';
import * as math from 'mathjs';

interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export class TradingBot {
  private exchange: ccxt.binance;
  private storage: IStorage;
  private isRunning: boolean = false;
  private loopInterval: NodeJS.Timeout | null = null;
  private config: any = {};
  private startTime: number = Date.now();

  constructor(storage: IStorage) {
    this.storage = storage;
    // Initialize exchange
    // Note: In a real app, you might load API keys from DB or Vault. 
    // Here we use env vars as per original config.
    this.exchange = new ccxt.binance({
      apiKey: process.env.BINANCE_API_KEY,
      secret: process.env.BINANCE_API_SECRET,
      enableRateLimit: true,
      options: { defaultType: 'future' },
    });
  }

  async updateConfig(newConfig: any) {
    this.config = { ...this.config, ...newConfig };
    await this.log('info', 'Configuration updated', this.config);
  }

  async getStatus() {
    let balance = { free: 0, total: 0, currency: 'USDT' };
    try {
        if (this.exchange.checkRequiredCredentials(false)) {
             const bal = await this.exchange.fetchBalance();
             balance = {
                 free: bal['USDT']?.free || 0,
                 total: bal['USDT']?.total || 0,
                 currency: 'USDT'
             };
        }
    } catch (e) {
        // Ignore balance errors if keys are invalid
    }

    return {
      isRunning: this.isRunning,
      uptime: Date.now() - this.startTime,
      balance
    };
  }

  async start() {
    if (this.isRunning) return;
    
    // Validate credentials
    if (!this.exchange.checkRequiredCredentials(false)) {
        // If keys are missing, we can't trade, but we can start the loop to show "Running" 
        // and maybe log errors. But better to fail start.
        if (!process.env.BINANCE_API_KEY) {
            throw new Error("Missing BINANCE_API_KEY and BINANCE_API_SECRET");
        }
    }

    this.config = await this.storage.getSettings();
    this.isRunning = true;
    this.startTime = Date.now();
    await this.log('success', 'Bot started');

    // Start loop
    this.loop();
    this.loopInterval = setInterval(() => this.loop(), 60 * 1000); // Run every minute
  }

  async stop() {
    this.isRunning = false;
    if (this.loopInterval) {
      clearInterval(this.loopInterval);
      this.loopInterval = null;
    }
    await this.log('warn', 'Bot stopped');
  }

  private async loop() {
    if (!this.isRunning) return;

    try {
      if (!this.config.tradingEnabled) {
          await this.log('info', 'Trading disabled in settings. Skipping loop.');
          return;
      }

      await this.log('info', 'Analyzing market...');
      const symbols = this.config.symbols || ['BTC/USDT', 'ETH/USDT'];
      
      // Fetch BTC for correlation
      const btcOhlcv = await this.fetchOHLCV('BTC/USDT');
      
      let bestPair = null;
      let bestEov = -Infinity;

      for (const symbol of symbols) {
        try {
          const ohlcv = await this.fetchOHLCV(symbol);
          const { eov, correlation } = this.calculateExpectedOutcome(ohlcv, btcOhlcv);
          
          await this.log('info', `Analyzed ${symbol}`, { eov, correlation });

          if (eov > bestEov) {
            bestEov = eov;
            bestPair = symbol;
          }
        } catch (err: any) {
          await this.log('error', `Error analyzing ${symbol}: ${err.message}`);
        }
      }

      if (bestPair && bestEov > 0.5) { // Threshold
         await this.executeTrade(bestPair, 'buy');
      }

    } catch (err: any) {
      await this.log('error', `Loop error: ${err.message}`);
    }
  }

  private async fetchOHLCV(symbol: string): Promise<OHLCV[]> {
    const ohlcv = await this.exchange.fetchOHLCV(symbol, this.config.timeframe || '15m', undefined, 100);
    return ohlcv.map(c => ({
      timestamp: c[0],
      open: c[1],
      high: c[2],
      low: c[3],
      close: c[4],
      volume: c[5]
    }));
  }

  private calculateExpectedOutcome(pairData: OHLCV[], btcData: OHLCV[]) {
    const closes = pairData.map(d => d.close);
    const btcCloses = btcData.map(d => d.close);
    
    // Ensure lengths match for correlation
    const minLen = Math.min(closes.length, btcCloses.length);
    const closesSliced = closes.slice(-minLen);
    const btcClosesSliced = btcCloses.slice(-minLen);

    // 1. Momentum Score
    const rsi = RSI.calculate({ values: closes, period: 14 });
    const macd = MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
    const roc = ROC.calculate({ values: closes, period: 10 });
    
    const lastRsi = rsi[rsi.length - 1] || 0;
    const lastMacd = macd[macd.length - 1];
    const lastRoc = roc[roc.length - 1] || 0;

    let score = 0;
    if (lastRsi > 55) score += 1;
    if (lastMacd && lastMacd.histogram && lastMacd.histogram > 0) score += 1;
    if (lastRoc > 0) score += 1;

    // 2. Correlation
    // simple correlation implementation
    const correlation = this.calculateCorrelation(closesSliced, btcClosesSliced);

    // 3. Volatility (ATR %)
    const atrInput = {
        high: pairData.map(d => d.high),
        low: pairData.map(d => d.low),
        close: pairData.map(d => d.close),
        period: 14
    };
    const atr = ATR.calculate(atrInput);
    const lastAtr = atr[atr.length - 1] || 0;
    const lastClose = closes[closes.length - 1];
    const vol = lastAtr / lastClose;

    const eov = score * correlation * vol;
    return { eov, correlation };
  }

  private calculateCorrelation(x: number[], y: number[]): number {
    const n = x.length;
    if (n === 0) return 0;
    const sumX = math.sum(x);
    const sumY = math.sum(y);
    const sumXY = math.sum(math.dotMultiply(x, y));
    const sumX2 = math.sum(math.dotMultiply(x, x));
    const sumY2 = math.sum(math.dotMultiply(y, y));

    const numerator = n * sumXY - sumX * sumY;
    const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
    
    if (denominator === 0) return 0;
    return numerator / denominator;
  }

  private async executeTrade(symbol: string, side: 'buy' | 'sell') {
    // Check if we already have an open trade for this symbol
    const openTrades = await this.storage.getTrades(10, 'open');
    if (openTrades.some(t => t.symbol === symbol)) {
        await this.log('info', `Already have open trade for ${symbol}`);
        return;
    }

    const balance = await this.exchange.fetchBalance();
    const usdtFree = balance['USDT']?.free || 0;
    const ticker = await this.exchange.fetchTicker(symbol);
    const price = ticker.last;

    if (!price) {
         await this.log('error', `Could not fetch price for ${symbol}`);
         return;
    }

    // Risk Calculation
    const riskPerTrade = this.config.riskPerTrade || 0.01; // 1%
    const atrInput = {
        high: [ticker.high!], // simplistic, ideally use history
        low: [ticker.low!],
        close: [price],
        period: 1
    };
    // Re-fetch full ATR for proper calculation
    const ohlcv = await this.fetchOHLCV(symbol);
    const atr = ATR.calculate({
        high: ohlcv.map(d => d.high),
        low: ohlcv.map(d => d.low),
        close: ohlcv.map(d => d.close),
        period: 14
    });
    const lastAtr = atr[atr.length - 1] || (price * 0.01);
    
    // Stop Distance
    const stopDistance = lastAtr * 2; // 2x ATR stop
    const stopPrice = side === 'buy' ? price - stopDistance : price + stopDistance;
    
    // Position Size
    // Risk Amount = Balance * Risk%
    // Qty = Risk Amount / Stop Distance
    const riskAmount = usdtFree * riskPerTrade;
    let qty = riskAmount / stopDistance;

    // Safety: Max Leverage Cap (e.g. 5x)
    const maxQty = (usdtFree * 5) / price;
    if (qty > maxQty) qty = maxQty;

    // FIX API PAYLOAD: Precision
    // Binance requires specific precision for quantity and price
    // ccxt provides helper methods for this
    await this.exchange.loadMarkets();
    const market = this.exchange.market(symbol);
    
    const amount = this.exchange.amountToPrecision(symbol, qty);
    
    await this.log('info', `Placing ${side} order for ${symbol}`, { amount, price, stopPrice });

    try {
        // Create Order
        const order = await this.exchange.createOrder(symbol, 'market', side, parseFloat(amount));
        
        await this.storage.createTrade({
            symbol,
            side,
            entryPrice: order.price || price,
            quantity: parseFloat(amount),
            status: 'open',
            pnl: 0
        });

        await this.log('success', `Opened ${side} position on ${symbol}`);

        // Add Stop Loss (Separate order)
        // Note: For Binance Futures, you can send params inside createOrder or create separate SL order
        // Here we create a separate STOP_MARKET order
        const slSide = side === 'buy' ? 'sell' : 'buy';
        const slPrice = this.exchange.priceToPrecision(symbol, stopPrice);
        
        await this.exchange.createOrder(symbol, 'STOP_MARKET', slSide, parseFloat(amount), undefined, {
            'stopPrice': parseFloat(slPrice),
            'closePosition': true // Important for Binance Futures SL
        });
        
        await this.log('info', `Placed Stop Loss at ${slPrice}`);

    } catch (err: any) {
        await this.log('error', `Trade execution failed: ${err.message}`);
    }
  }

  private async log(level: string, message: string, data?: any) {
    console.log(`[${level.toUpperCase()}] ${message}`, data || '');
    await this.storage.createLog({
        level,
        message,
        data: data ? JSON.stringify(data) : null
    });
  }
}
