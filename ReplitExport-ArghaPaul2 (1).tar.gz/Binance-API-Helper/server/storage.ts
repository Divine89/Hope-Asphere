import { db } from "./db";
import {
  settings, trades, logs,
  type Settings, type InsertSettings,
  type Trade, type InsertTrade,
  type Log, type InsertLog
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Settings
  getSettings(): Promise<Settings>;
  updateSettings(updates: Partial<InsertSettings>): Promise<Settings>;

  // Trades
  getTrades(limit?: number, status?: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: number, updates: Partial<InsertTrade>): Promise<Trade>;
  
  // Logs
  getLogs(limit?: number, level?: string): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;
}

export class DatabaseStorage implements IStorage {
  async getSettings(): Promise<Settings> {
    const existing = await db.select().from(settings).limit(1);
    if (existing.length === 0) {
      // Create default settings if none exist
      const [created] = await db.insert(settings).values({
        riskPerTrade: 0.01,
        timeframe: "15m",
        tradingEnabled: false,
        symbols: ["BTC/USDT", "ETH/USDT"],
      }).returning();
      return created;
    }
    return existing[0];
  }

  async updateSettings(updates: Partial<InsertSettings>): Promise<Settings> {
    const existing = await this.getSettings();
    const [updated] = await db.update(settings)
      .set(updates)
      .where(eq(settings.id, existing.id))
      .returning();
    return updated;
  }

  async getTrades(limit: number = 50, status?: string): Promise<Trade[]> {
    let query = db.select().from(trades).orderBy(desc(trades.openedAt));
    if (status) {
      // @ts-ignore
      query = query.where(eq(trades.status, status));
    }
    // @ts-ignore
    return await query.limit(limit);
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [created] = await db.insert(trades).values(trade).returning();
    return created;
  }

  async updateTrade(id: number, updates: Partial<InsertTrade>): Promise<Trade> {
    const [updated] = await db.update(trades)
      .set(updates)
      .where(eq(trades.id, id))
      .returning();
    return updated;
  }

  async getLogs(limit: number = 100, level?: string): Promise<Log[]> {
    let query = db.select().from(logs).orderBy(desc(logs.timestamp));
    if (level) {
      // @ts-ignore
      query = query.where(eq(logs.level, level));
    }
    // @ts-ignore
    return await query.limit(limit);
  }

  async createLog(log: InsertLog): Promise<Log> {
    const [created] = await db.insert(logs).values(log).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
